import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import {
  Calendar, Users, Cloud, Star, Brain, Activity, Clock, ShieldAlert, CheckCircle2, TrendingUp, ChevronRight
} from 'lucide-react';
import api from '../utils/api';
import toast from 'react-hot-toast';
import { Card } from '../components/ui/Card';
import Button from '../components/ui/Button';
import { Input, Select } from '../components/ui/Input';
import AnimatedNumber from '../components/ui/AnimatedNumber';
import { motion, AnimatePresence } from 'framer-motion';
import { pageForwardSlide, staggerContainer, staggerItem } from '../utils/animations';

function AIProcessingStage({ stage }) {
  const stages = [
    'Integrating historical demand data...',
    'Evaluating Genpact menu preferences...',
    'Mapping HPI waste probability distributions...',
    'Running Dish-Level Model Ensembles...',
    'Generating prevention strategy...'
  ];

  return (
    <motion.div 
      className="absolute inset-0 z-30 bg-[var(--surface)]/90 backdrop-blur-md flex flex-col items-center justify-center rounded-3xl overflow-hidden"
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
    >
      <div className="relative w-48 h-48 flex items-center justify-center mb-8">
        <motion.div className="absolute inset-0 rounded-full border border-brand-500/30" animate={{ scale: [1, 2, 1], opacity: [0.5, 0, 0.5] }} transition={{ duration: 2, repeat: Infinity }} />
        <motion.div className="absolute inset-4 rounded-full border border-accent-500/30 border-dashed" animate={{ rotate: 360 }} transition={{ duration: 4, repeat: Infinity, ease: 'linear' }} />
        <motion.div className="absolute inset-8 rounded-full border border-violet-500/30 border-dashed" animate={{ rotate: -360 }} transition={{ duration: 6, repeat: Infinity, ease: 'linear' }} />
        <div className="relative z-10 w-16 h-16 bg-slate-900 rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(16,185,129,0.3)] border border-brand-500/50">
          <Brain className="w-8 h-8 text-brand-400" />
        </div>
      </div>
      <div className="text-center h-16">
        <AnimatePresence mode="wait">
          <motion.p 
            key={stage}
            initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
            className="text-brand-400 font-bold uppercase tracking-widest text-sm"
          >
            {stages[stage] || 'Processing...'}
          </motion.p>
        </AnimatePresence>
      </div>
    </motion.div>
  );
}

export default function PredictionPage() {
  const { register, handleSubmit } = useForm();
  const [loading, setLoading] = useState(false);
  const [stage, setStage] = useState(0);
  const [result, setResult] = useState(null);

  const onSubmit = async (data) => {
    setLoading(true);
    setResult(null);
    setStage(0);
    
    const stageInterval = setInterval(() => {
      setStage(prev => {
        if (prev >= 4) { clearInterval(stageInterval); return prev; }
        return prev + 1;
      });
    }, 600);

    try {
      const response = await api.post('/prediction', data);
      clearInterval(stageInterval);
      if (response.data.error) {
        toast.error(response.data.error);
      } else {
        setResult(response.data);
        toast.success('Dish-Level Forecast generated.');
      }
      setLoading(false);
    } catch (error) {
      clearInterval(stageInterval);
      setLoading(false);
      toast.error('Failed to generate prediction');
    }
  };

  return (
    <motion.div variants={pageForwardSlide} initial="initial" animate="animate" exit="exit" className="max-w-[1600px] mx-auto min-h-[calc(100vh-100px)] flex flex-col space-y-6">
      <div className="flex items-center justify-between shrink-0">
        <div>
          <h1 className="text-3xl font-black text-[var(--text-primary)] tracking-tight flex items-center gap-3">
            <Brain className="w-8 h-8 text-accent-500" /> Forecasting Engine
          </h1>
          <p className="text-[var(--text-muted)] font-medium mt-1">Dish-level AI prediction for food demand, preparation scaling, and waste prevention.</p>
        </div>
      </div>

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* ===================================== */}
        {/* LEFT: CONTROLS */}
        {/* ===================================== */}
        <div className="lg:col-span-3 flex flex-col gap-6">
          <Card className="p-6 rounded-3xl border-[var(--border)] relative overflow-hidden group shadow-2xl">
            <div className="absolute top-0 right-0 w-32 h-32 bg-accent-500/10 rounded-full blur-2xl -mr-10 -mt-10" />
            <div className="relative z-10">
              <div className="flex items-center gap-2 mb-6 pb-4 border-b border-[var(--border)]">
                <ChevronRight className="w-5 h-5 text-accent-500" />
                <h3 className="text-sm font-bold text-[var(--text-primary)] uppercase tracking-wider">Forecast Parameters</h3>
              </div>
              
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
                <div>
                  <label className="block text-[10px] font-bold text-[var(--text-muted)] uppercase tracking-widest mb-1.5">Target Date</label>
                  <Input type="date" icon={Calendar} required {...register("date")} className="h-10 bg-[var(--surface-hover)] text-sm" />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-[var(--text-muted)] uppercase tracking-widest mb-1.5">Meal Phase</label>
                  <Select icon={Clock} required {...register("meal_type")} className="h-10 bg-[var(--surface-hover)] text-sm">
                    <option value="breakfast">Breakfast</option>
                    <option value="lunch">Lunch</option>
                    <option value="dinner">Dinner</option>
                  </Select>
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-[var(--text-muted)] uppercase tracking-widest mb-1.5">Expected Population</label>
                  <Input type="number" placeholder="150" icon={Users} required min="1" {...register("people")} className="h-10 bg-[var(--surface-hover)] text-sm" />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-[var(--text-muted)] uppercase tracking-widest mb-1.5">Environment</label>
                  <Select icon={Cloud} {...register("weather")} className="h-10 bg-[var(--surface-hover)] text-sm">
                    <option value="sunny">Sunny</option>
                    <option value="rainy">Rainy</option>
                    <option value="cloudy">Cloudy</option>
                  </Select>
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-[var(--text-muted)] uppercase tracking-widest mb-1.5">Occasion</label>
                  <Select icon={Star} {...register("special_event")} className="h-10 bg-[var(--surface-hover)] text-sm">
                    <option value="none">Standard</option>
                    <option value="holiday">Holiday</option>
                    <option value="festival">Festival</option>
                  </Select>
                </div>

                <Button type="submit" size="lg" className="w-full h-12 mt-4 bg-accent-600 hover:bg-accent-700 text-white rounded-xl shadow-xl shadow-accent-500/20 text-sm" disabled={loading}>
                  {loading ? 'Initializing Ensembles...' : 'Generate AI Forecast'}
                </Button>
              </form>
            </div>
          </Card>
        </div>

        {/* ===================================== */}
        {/* RIGHT: VISUALIZATION & RESULTS */}
        {/* ===================================== */}
        <div className="lg:col-span-9 flex flex-col gap-6 relative">
          
          <AnimatePresence>
            {loading && <AIProcessingStage stage={stage} />}
          </AnimatePresence>

          {!result && !loading && (
             <Card className="flex-1 p-6 rounded-3xl border-[var(--border)] min-h-[400px] flex flex-col items-center justify-center opacity-50 border-dashed">
                <Brain className="w-16 h-16 text-[var(--text-muted)] mb-4" />
                <h3 className="font-bold text-[var(--text-primary)] mb-2">Awaiting Parameters</h3>
                <p className="text-sm font-medium text-[var(--text-muted)] max-w-sm text-center">Set your forecast parameters to predict dish-level preparation quantities and receive an AI waste prevention plan.</p>
             </Card>
          )}

          {result && !loading && (
             <motion.div variants={staggerContainer} initial="initial" animate="animate" className="flex flex-col gap-6">
                
                {/* Global Metrics Row */}
                <motion.div variants={staggerItem} className="grid grid-cols-3 gap-6">
                  <Card className="p-5 rounded-3xl border-[var(--border)] bg-brand-500/5 flex items-center justify-between">
                    <div>
                      <p className="text-[10px] font-bold text-brand-600 dark:text-brand-400 uppercase tracking-widest mb-1">Total Preparation</p>
                      <p className="text-3xl font-black text-[var(--text-primary)]"><AnimatedNumber value={result.total_preparation_kg} /> <span className="text-sm text-brand-500">kg</span></p>
                    </div>
                  </Card>
                  <Card className="p-5 rounded-3xl border-[var(--border)] bg-emerald-500/5 flex items-center justify-between">
                    <div>
                      <p className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-widest mb-1">Expected Consumption</p>
                      <p className="text-3xl font-black text-[var(--text-primary)]"><AnimatedNumber value={result.total_preparation_kg - result.total_expected_waste_kg} /> <span className="text-sm text-emerald-500">kg</span></p>
                    </div>
                  </Card>
                  <Card className="p-5 rounded-3xl border-[var(--border)] bg-amber-500/5 flex items-center justify-between">
                    <div>
                      <p className="text-[10px] font-bold text-amber-600 dark:text-amber-400 uppercase tracking-widest mb-1">Expected Waste</p>
                      <p className="text-3xl font-black text-[var(--text-primary)]"><AnimatedNumber value={result.total_expected_waste_kg} /> <span className="text-sm text-amber-500">kg</span></p>
                    </div>
                  </Card>
                </motion.div>

                {/* Dish Table */}
                <motion.div variants={staggerItem}>
                  <Card className="rounded-3xl border-[var(--border)] overflow-hidden">
                    <div className="p-5 border-b border-[var(--border)] bg-[var(--surface-hover)]">
                      <h3 className="text-sm font-bold text-[var(--text-primary)] uppercase tracking-wider flex items-center gap-2"><TrendingUp className="w-4 h-4 text-accent-500"/> Dish-Level Forecast</h3>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm text-left">
                        <thead className="bg-[var(--surface)] text-[10px] uppercase tracking-widest text-[var(--text-muted)]">
                          <tr>
                            <th className="px-6 py-4 font-bold">Category</th>
                            <th className="px-6 py-4 font-bold">Dish</th>
                            <th className="px-6 py-4 font-bold text-right">Prep (kg)</th>
                            <th className="px-6 py-4 font-bold text-right">Consume (kg)</th>
                            <th className="px-6 py-4 font-bold text-right">Waste (kg)</th>
                            <th className="px-6 py-4 font-bold text-center">Waste %</th>
                            <th className="px-6 py-4 font-bold">Risk Level</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[var(--border)]">
                          {result.items.map((item, idx) => (
                            <tr key={idx} className="hover:bg-[var(--surface-hover)] transition-colors">
                              <td className="px-6 py-4 font-medium text-[var(--text-muted)]">{item.category}</td>
                              <td className="px-6 py-4 font-bold text-[var(--text-primary)]">{item.dish_name}</td>
                              <td className="px-6 py-4 font-black text-brand-600 dark:text-brand-400 text-right">{item.recommended_preparation_kg}</td>
                              <td className="px-6 py-4 font-medium text-emerald-600 dark:text-emerald-400 text-right">{item.expected_consumption_kg}</td>
                              <td className="px-6 py-4 font-medium text-amber-600 dark:text-amber-400 text-right">{item.expected_waste_kg}</td>
                              <td className="px-6 py-4 font-bold text-center">{item.expected_waste_percentage}%</td>
                              <td className="px-6 py-4">
                                <span className={`px-2 py-1 text-[10px] font-bold uppercase tracking-widest rounded-md border ${
                                  item.risk_level === 'High' ? 'bg-red-500/10 text-red-500 border-red-500/30' :
                                  item.risk_level === 'Medium' ? 'bg-amber-500/10 text-amber-500 border-amber-500/30' :
                                  'bg-emerald-500/10 text-emerald-500 border-emerald-500/30'
                                }`}>
                                  {item.risk_level}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </Card>
                </motion.div>

                {/* Prevention Plan */}
                <motion.div variants={staggerItem}>
                  <Card className="p-6 rounded-3xl border-violet-500/30 bg-violet-500/5 shadow-xl relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-violet-500/10 rounded-full blur-2xl -mr-10 -mt-10" />
                    <div className="flex items-center gap-2 mb-4 relative z-10">
                      <ShieldAlert className="w-5 h-5 text-violet-500" />
                      <h3 className="text-sm font-bold text-[var(--text-primary)] uppercase tracking-wider">AI Prevention Plan</h3>
                    </div>
                    <ul className="space-y-3 relative z-10">
                      {result.preventive_actions.map((action, idx) => (
                        <li key={idx} className="flex items-start gap-3">
                          <CheckCircle2 className="w-5 h-5 text-violet-500 shrink-0 mt-0.5" />
                          <span className="font-medium text-sm text-[var(--text-secondary)]">{action}</span>
                        </li>
                      ))}
                    </ul>
                  </Card>
                </motion.div>

             </motion.div>
          )}

        </div>
      </div>
    </motion.div>
  );
}
