import os
import joblib
import pandas as pd
import numpy as np
import datetime
from ml_pipeline.data_integration import DataIntegrationLayer

class PredictionPipeline:
    def __init__(self):
        self.models_dir = os.path.join(os.path.dirname(__file__), "../saved_models")
        self.demand_model = joblib.load(os.path.join(self.models_dir, "demand_model.pkl"))
        self.waste_model = joblib.load(os.path.join(self.models_dir, "waste_model.pkl"))
        self.category_mapping = joblib.load(os.path.join(self.models_dir, "category_mapping.pkl"))
        self.macro_mapping = joblib.load(os.path.join(self.models_dir, "macro_mapping.pkl"))
        self.integration_layer = DataIntegrationLayer()
        
        # Reverse mappings
        self.cat_to_code = {v: k for k, v in self.category_mapping.items()}
        self.macro_to_code = {v: k for k, v in self.macro_mapping.items()}

    def predict_dish_level_forecast(self, date_str: str, expected_attendance: int, meal_type: str):
        # 1. Base input vector for Genpact demand model (Generic Indian subsets)
        # Using today's week as proxy
        week_num = datetime.datetime.strptime(date_str, "%Y-%m-%d").isocalendar()[1]
        
        # Weather/Promotions/etc placeholder context
        promo = 1 if expected_attendance > 500 else 0
        
        results = []
        total_prep = 0.0
        total_waste = 0.0
        
        # Genpact model categories mapped to Indian
        base_categories = ["Rice Bowl", "Biryani", "Indian_Curry", "Soup", "Beverages"]
        
        for cat in base_categories:
            code = self.cat_to_code.get(cat, 0)
            X = pd.DataFrame([{
                'week': week_num, 
                'checkout_price': 150, 
                'emailer_for_promotion': promo, 
                'homepage_featured': 1 if promo else 0, 
                'discount_percent': 0.1, 
                'category_encoded': code
            }])
            
            # MODEL 1 & 2: Predict demand (Orders)
            predicted_demand = max(0, float(self.demand_model.predict(X)[0]))
            
            # Scale orders up to expected attendance if attendance is significantly larger
            # (Data Integration logic)
            scale_factor = expected_attendance / 200.0
            adjusted_demand = predicted_demand * scale_factor
            
            # Translate to Indian Dishes
            dish_demands = self.integration_layer.map_genpact_demand(cat, adjusted_demand)
            
            for dish_name, dish_orders in dish_demands.items():
                if dish_orders <= 0: continue
                
                # MODEL 3: Recommended Preparation Quantity (kg)
                serving_weight = self.integration_layer.get_serving_weight(dish_name)
                prep_kg = round(dish_orders * serving_weight, 1)
                
                # MODEL 4: Waste Prediction
                macro = self.integration_layer.DISH_TO_MACRO_CATEGORY.get(dish_name, "Vegetables")
                macro_code = self.macro_to_code.get(macro, 0)
                
                X_waste = pd.DataFrame([{
                    'macro_encoded': macro_code,
                    'mass_prepared': prep_kg
                }])
                
                waste_pct = max(0.01, min(0.99, float(self.waste_model.predict(X_waste)[0])))
                waste_kg = round(prep_kg * waste_pct, 1)
                consumed_kg = round(prep_kg - waste_kg, 1)
                
                # Risk level
                if waste_pct > 0.12: risk = "High"
                elif waste_pct > 0.08: risk = "Medium"
                else: risk = "Low"
                
                total_prep += prep_kg
                total_waste += waste_kg
                
                results.append({
                    "category": cat,
                    "dish_name": dish_name,
                    "recommended_preparation_kg": prep_kg,
                    "expected_consumption_kg": consumed_kg,
                    "expected_waste_kg": waste_kg,
                    "expected_waste_percentage": round(waste_pct * 100, 1),
                    "risk_level": risk
                })
        
        # Sort results by prep kg descending
        results.sort(key=lambda x: x["recommended_preparation_kg"], reverse=True)
        
        # MODEL 5: Waste Prevention Interventions
        preventive_actions = []
        if total_waste / max(1, total_prep) > 0.10:
            preventive_actions.append("Reduce initial batch preparation for High-Risk items by 10%.")
            preventive_actions.append("Implement staggered cooking for Rice items based on live attendance.")
        else:
            preventive_actions.append("Maintain current batching schedule; waste risk is acceptable.")
            
        return {
            "forecast_date": date_str,
            "meal_type": meal_type,
            "expected_attendance": expected_attendance,
            "items": results,
            "total_preparation_kg": round(total_prep, 1),
            "total_expected_waste_kg": round(total_waste, 1),
            "preventive_actions": preventive_actions
        }
